<!doctype html>
<html lang="pt-BR" class="no-js" itemtype="https://schema.org/WebPage" itemscope>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v23.4 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Página não encontrada - Tabakka</title>
	<meta property="og:locale" content="pt_BR" />
	<meta property="og:title" content="Página não encontrada - Tabakka" />
	<meta property="og:site_name" content="Tabakka" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://tabakkatabacaria.com/#website","url":"https://tabakkatabacaria.com/","name":"Tabakka","description":"Tabacaria","publisher":{"@id":"https://tabakkatabacaria.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://tabakkatabacaria.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"pt-BR"},{"@type":"Organization","@id":"https://tabakkatabacaria.com/#organization","name":"Tabakka","url":"https://tabakkatabacaria.com/","logo":{"@type":"ImageObject","inLanguage":"pt-BR","@id":"https://tabakkatabacaria.com/#/schema/logo/image/","url":"https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria.png","contentUrl":"https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria.png","width":300,"height":169,"caption":"Tabakka"},"image":{"@id":"https://tabakkatabacaria.com/#/schema/logo/image/"}}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel="alternate" type="application/rss+xml" title="Feed para Tabakka &raquo;" href="https://tabakkatabacaria.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para Tabakka &raquo;" href="https://tabakkatabacaria.com/comments/feed/" />
			<script>document.documentElement.classList.remove( 'no-js' );</script>
			<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/tabakkatabacaria.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.6.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<link rel='stylesheet' id='sbi_styles-css' href='https://tabakkatabacaria.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=6.5.0' media='all' />
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://tabakkatabacaria.com/wp-includes/css/dist/block-library/style.min.css?ver=6.6.2' media='all' />
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--theme-palette-1: var(--global-palette1);--wp--preset--color--theme-palette-2: var(--global-palette2);--wp--preset--color--theme-palette-3: var(--global-palette3);--wp--preset--color--theme-palette-4: var(--global-palette4);--wp--preset--color--theme-palette-5: var(--global-palette5);--wp--preset--color--theme-palette-6: var(--global-palette6);--wp--preset--color--theme-palette-7: var(--global-palette7);--wp--preset--color--theme-palette-8: var(--global-palette8);--wp--preset--color--theme-palette-9: var(--global-palette9);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: var(--global-font-size-small);--wp--preset--font-size--medium: var(--global-font-size-medium);--wp--preset--font-size--large: var(--global-font-size-large);--wp--preset--font-size--x-large: 42px;--wp--preset--font-size--larger: var(--global-font-size-larger);--wp--preset--font-size--xxlarge: var(--global-font-size-xxlarge);--wp--preset--font-family--inter: "Inter", sans-serif;--wp--preset--font-family--cardo: Cardo;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<style id='woocommerce-inline-inline-css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='woo-variation-swatches-css' href='https://tabakkatabacaria.com/wp-content/plugins/woo-variation-swatches/assets/css/frontend.min.css?ver=1725632304' media='all' />
<style id='woo-variation-swatches-inline-css'>
:root {
--wvs-tick:url("data:image/svg+xml;utf8,%3Csvg filter='drop-shadow(0px 0px 2px rgb(0 0 0 / .8))' xmlns='http://www.w3.org/2000/svg'  viewBox='0 0 30 30'%3E%3Cpath fill='none' stroke='%23ffffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='4' d='M4 16L11 23 27 7'/%3E%3C/svg%3E");

--wvs-cross:url("data:image/svg+xml;utf8,%3Csvg filter='drop-shadow(0px 0px 5px rgb(255 255 255 / .6))' xmlns='http://www.w3.org/2000/svg' width='72px' height='72px' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='%23ff0000' stroke-linecap='round' stroke-width='0.6' d='M5 5L19 19M19 5L5 19'/%3E%3C/svg%3E");
--wvs-single-product-item-width:30px;
--wvs-single-product-item-height:30px;
--wvs-single-product-item-font-size:16px}
</style>
<link rel='stylesheet' id='woobt-frontend-css' href='https://tabakkatabacaria.com/wp-content/plugins/woo-bought-together-premium/assets/css/frontend.css?ver=5.1.1' media='all' />
<link rel='stylesheet' id='woosb-frontend-css' href='https://tabakkatabacaria.com/wp-content/plugins/woo-product-bundle-premium/assets/css/frontend.css?ver=7.0.5' media='all' />
<link rel='stylesheet' id='dgwt-wcas-style-css' href='https://tabakkatabacaria.com/wp-content/plugins/ajax-search-for-woocommerce/assets/css/style.min.css?ver=1.28.1' media='all' />
<link rel='stylesheet' id='kadence-global-css' href='https://tabakkatabacaria.com/wp-content/themes/kadence/assets/css/global.min.css?ver=1.2.9' media='all' />
<style id='kadence-global-inline-css'>
/* Kadence Base CSS */
:root{--global-palette1:#4285f4;--global-palette2:#185abc;--global-palette3:#000000;--global-palette4:#2d3e50;--global-palette5:#414141;--global-palette6:#656565;--global-palette7:#ebebeb;--global-palette8:#fafafa;--global-palette9:#ffffff;--global-palette9rgb:255, 255, 255;--global-palette-highlight:var(--global-palette1);--global-palette-highlight-alt:var(--global-palette2);--global-palette-highlight-alt2:var(--global-palette9);--global-palette-btn-bg:var(--global-palette1);--global-palette-btn-bg-hover:var(--global-palette2);--global-palette-btn:var(--global-palette9);--global-palette-btn-hover:var(--global-palette9);--global-body-font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";--global-heading-font-family:inherit;--global-primary-nav-font-family:inherit;--global-fallback-font:sans-serif;--global-display-fallback-font:sans-serif;--global-content-width:1290px;--global-content-narrow-width:842px;--global-content-edge-padding:1.5rem;--global-content-boxed-padding:2rem;--global-calc-content-width:calc(1290px - var(--global-content-edge-padding) - var(--global-content-edge-padding) );--wp--style--global--content-size:var(--global-calc-content-width);}.wp-site-blocks{--global-vw:calc( 100vw - ( 0.5 * var(--scrollbar-offset)));}:root body.kadence-elementor-colors{--e-global-color-kadence1:var(--global-palette1);--e-global-color-kadence2:var(--global-palette2);--e-global-color-kadence3:var(--global-palette3);--e-global-color-kadence4:var(--global-palette4);--e-global-color-kadence5:var(--global-palette5);--e-global-color-kadence6:var(--global-palette6);--e-global-color-kadence7:var(--global-palette7);--e-global-color-kadence8:var(--global-palette8);--e-global-color-kadence9:var(--global-palette9);}body{background:var(--global-palette8);}body, input, select, optgroup, textarea{font-weight:400;font-size:17px;line-height:1.6;font-family:var(--global-body-font-family);color:var(--global-palette4);}.content-bg, body.content-style-unboxed .site{background:var(--global-palette9);}h1,h2,h3,h4,h5,h6{font-family:var(--global-heading-font-family);}h1{font-weight:700;font-size:32px;line-height:1.5;color:var(--global-palette3);}h2{font-weight:700;font-size:28px;line-height:1.5;color:var(--global-palette3);}h3{font-weight:700;font-size:24px;line-height:1.5;color:var(--global-palette3);}h4{font-weight:700;font-size:22px;line-height:1.5;color:var(--global-palette4);}h5{font-weight:700;font-size:20px;line-height:1.5;color:var(--global-palette4);}h6{font-weight:700;font-size:18px;line-height:1.5;color:var(--global-palette5);}.entry-hero .kadence-breadcrumbs{max-width:1290px;}.site-container, .site-header-row-layout-contained, .site-footer-row-layout-contained, .entry-hero-layout-contained, .comments-area, .alignfull > .wp-block-cover__inner-container, .alignwide > .wp-block-cover__inner-container{max-width:var(--global-content-width);}.content-width-narrow .content-container.site-container, .content-width-narrow .hero-container.site-container{max-width:var(--global-content-narrow-width);}@media all and (min-width: 1520px){.wp-site-blocks .content-container  .alignwide{margin-left:-115px;margin-right:-115px;width:unset;max-width:unset;}}@media all and (min-width: 1102px){.content-width-narrow .wp-site-blocks .content-container .alignwide{margin-left:-130px;margin-right:-130px;width:unset;max-width:unset;}}.content-style-boxed .wp-site-blocks .entry-content .alignwide{margin-left:calc( -1 * var( --global-content-boxed-padding ) );margin-right:calc( -1 * var( --global-content-boxed-padding ) );}.content-area{margin-top:5rem;margin-bottom:5rem;}@media all and (max-width: 1024px){.content-area{margin-top:3rem;margin-bottom:3rem;}}@media all and (max-width: 767px){.content-area{margin-top:2rem;margin-bottom:2rem;}}@media all and (max-width: 1024px){:root{--global-content-boxed-padding:2rem;}}@media all and (max-width: 767px){:root{--global-content-boxed-padding:1.5rem;}}.entry-content-wrap{padding:2rem;}@media all and (max-width: 1024px){.entry-content-wrap{padding:2rem;}}@media all and (max-width: 767px){.entry-content-wrap{padding:1.5rem;}}.entry.single-entry{box-shadow:0px 15px 15px -10px rgba(0,0,0,0.05);}.entry.loop-entry{box-shadow:0px 15px 15px -10px rgba(0,0,0,0.05);}.loop-entry .entry-content-wrap{padding:2rem;}@media all and (max-width: 1024px){.loop-entry .entry-content-wrap{padding:2rem;}}@media all and (max-width: 767px){.loop-entry .entry-content-wrap{padding:1.5rem;}}button, .button, .wp-block-button__link, input[type="button"], input[type="reset"], input[type="submit"], .fl-button, .elementor-button-wrapper .elementor-button{box-shadow:0px 0px 0px -7px rgba(0,0,0,0);}button:hover, button:focus, button:active, .button:hover, .button:focus, .button:active, .wp-block-button__link:hover, .wp-block-button__link:focus, .wp-block-button__link:active, input[type="button"]:hover, input[type="button"]:focus, input[type="button"]:active, input[type="reset"]:hover, input[type="reset"]:focus, input[type="reset"]:active, input[type="submit"]:hover, input[type="submit"]:focus, input[type="submit"]:active, .elementor-button-wrapper .elementor-button:hover, .elementor-button-wrapper .elementor-button:focus, .elementor-button-wrapper .elementor-button:active{box-shadow:0px 15px 25px -7px rgba(0,0,0,0.1);}.kb-button.kb-btn-global-outline.kb-btn-global-inherit{padding-top:calc(px - 2px);padding-right:calc(px - 2px);padding-bottom:calc(px - 2px);padding-left:calc(px - 2px);}@media all and (min-width: 1025px){.transparent-header .entry-hero .entry-hero-container-inner{padding-top:80px;}}@media all and (max-width: 1024px){.mobile-transparent-header .entry-hero .entry-hero-container-inner{padding-top:80px;}}@media all and (max-width: 767px){.mobile-transparent-header .entry-hero .entry-hero-container-inner{padding-top:80px;}}
/* Kadence Header CSS */
@media all and (max-width: 1024px){.mobile-transparent-header #masthead{position:absolute;left:0px;right:0px;z-index:100;}.kadence-scrollbar-fixer.mobile-transparent-header #masthead{right:var(--scrollbar-offset,0);}.mobile-transparent-header #masthead, .mobile-transparent-header .site-top-header-wrap .site-header-row-container-inner, .mobile-transparent-header .site-main-header-wrap .site-header-row-container-inner, .mobile-transparent-header .site-bottom-header-wrap .site-header-row-container-inner{background:transparent;}.site-header-row-tablet-layout-fullwidth, .site-header-row-tablet-layout-standard{padding:0px;}}@media all and (min-width: 1025px){.transparent-header #masthead{position:absolute;left:0px;right:0px;z-index:100;}.transparent-header.kadence-scrollbar-fixer #masthead{right:var(--scrollbar-offset,0);}.transparent-header #masthead, .transparent-header .site-top-header-wrap .site-header-row-container-inner, .transparent-header .site-main-header-wrap .site-header-row-container-inner, .transparent-header .site-bottom-header-wrap .site-header-row-container-inner{background:transparent;}}.site-branding a.brand img{max-width:200px;}.site-branding a.brand img.svg-logo-image{width:200px;}.site-branding{padding:0px 0px 0px 0px;}.site-branding .site-title{font-weight:700;font-size:26px;line-height:1.2;color:var(--global-palette3);}#masthead, #masthead .kadence-sticky-header.item-is-fixed:not(.item-at-start):not(.site-header-row-container):not(.site-main-header-wrap), #masthead .kadence-sticky-header.item-is-fixed:not(.item-at-start) > .site-header-row-container-inner{background:#ffffff;}.site-main-header-inner-wrap{min-height:80px;}.header-navigation[class*="header-navigation-style-underline"] .header-menu-container.primary-menu-container>ul>li>a:after{width:calc( 100% - 1.2em);}.main-navigation .primary-menu-container > ul > li.menu-item > a{padding-left:calc(1.2em / 2);padding-right:calc(1.2em / 2);padding-top:0.6em;padding-bottom:0.6em;color:var(--global-palette5);}.main-navigation .primary-menu-container > ul > li.menu-item .dropdown-nav-special-toggle{right:calc(1.2em / 2);}.main-navigation .primary-menu-container > ul > li.menu-item > a:hover{color:var(--global-palette-highlight);}.main-navigation .primary-menu-container > ul > li.menu-item.current-menu-item > a{color:var(--global-palette3);}.header-navigation .header-menu-container ul ul.sub-menu, .header-navigation .header-menu-container ul ul.submenu{background:var(--global-palette3);box-shadow:0px 2px 13px 0px rgba(0,0,0,0.1);}.header-navigation .header-menu-container ul ul li.menu-item, .header-menu-container ul.menu > li.kadence-menu-mega-enabled > ul > li.menu-item > a{border-bottom:1px solid rgba(255,255,255,0.1);}.header-navigation .header-menu-container ul ul li.menu-item > a{width:200px;padding-top:1em;padding-bottom:1em;color:var(--global-palette8);font-size:12px;}.header-navigation .header-menu-container ul ul li.menu-item > a:hover{color:var(--global-palette9);background:var(--global-palette4);}.header-navigation .header-menu-container ul ul li.menu-item.current-menu-item > a{color:var(--global-palette9);background:var(--global-palette4);}.mobile-toggle-open-container .menu-toggle-open, .mobile-toggle-open-container .menu-toggle-open:focus{color:var(--global-palette5);padding:0.4em 0.6em 0.4em 0.6em;font-size:14px;}.mobile-toggle-open-container .menu-toggle-open.menu-toggle-style-bordered{border:1px solid currentColor;}.mobile-toggle-open-container .menu-toggle-open .menu-toggle-icon{font-size:20px;}.mobile-toggle-open-container .menu-toggle-open:hover, .mobile-toggle-open-container .menu-toggle-open:focus-visible{color:var(--global-palette-highlight);}.mobile-navigation ul li{font-size:14px;}.mobile-navigation ul li a{padding-top:1em;padding-bottom:1em;}.mobile-navigation ul li > a, .mobile-navigation ul li.menu-item-has-children > .drawer-nav-drop-wrap{color:var(--global-palette8);}.mobile-navigation ul li.current-menu-item > a, .mobile-navigation ul li.current-menu-item.menu-item-has-children > .drawer-nav-drop-wrap{color:var(--global-palette-highlight);}.mobile-navigation ul li.menu-item-has-children .drawer-nav-drop-wrap, .mobile-navigation ul li:not(.menu-item-has-children) a{border-bottom:1px solid rgba(255,255,255,0.1);}.mobile-navigation:not(.drawer-navigation-parent-toggle-true) ul li.menu-item-has-children .drawer-nav-drop-wrap button{border-left:1px solid rgba(255,255,255,0.1);}#mobile-drawer .drawer-header .drawer-toggle{padding:0.6em 0.15em 0.6em 0.15em;font-size:24px;}
/* Kadence Footer CSS */
.site-bottom-footer-inner-wrap{padding-top:30px;padding-bottom:30px;grid-column-gap:30px;}.site-bottom-footer-inner-wrap .widget{margin-bottom:30px;}.site-bottom-footer-inner-wrap .site-footer-section:not(:last-child):after{right:calc(-30px / 2);}
/* Kadence Woo CSS */
.woocommerce table.shop_table td.product-quantity{min-width:130px;}.entry-hero.product-hero-section .entry-header{min-height:200px;}.product-title .single-category{font-weight:700;font-size:32px;line-height:1.5;color:var(--global-palette3);}.wp-site-blocks .product-hero-section .extra-title{font-weight:700;font-size:32px;line-height:1.5;}.woocommerce ul.products.woo-archive-btn-button .product-action-wrap .button:not(.kb-button), .woocommerce ul.products li.woo-archive-btn-button .button:not(.kb-button), .wc-block-grid__product.woo-archive-btn-button .product-details .wc-block-grid__product-add-to-cart .wp-block-button__link{border:2px none transparent;box-shadow:0px 0px 0px 0px rgba(0,0,0,0.0);}.woocommerce ul.products.woo-archive-btn-button .product-action-wrap .button:not(.kb-button):hover, .woocommerce ul.products li.woo-archive-btn-button .button:not(.kb-button):hover, .wc-block-grid__product.woo-archive-btn-button .product-details .wc-block-grid__product-add-to-cart .wp-block-button__link:hover{box-shadow:0px 0px 0px 0px rgba(0,0,0,0);}
</style>
<link rel='stylesheet' id='kadence-header-css' href='https://tabakkatabacaria.com/wp-content/themes/kadence/assets/css/header.min.css?ver=1.2.9' media='all' />
<link rel='stylesheet' id='kadence-content-css' href='https://tabakkatabacaria.com/wp-content/themes/kadence/assets/css/content.min.css?ver=1.2.9' media='all' />
<link rel='stylesheet' id='kadence-woocommerce-css' href='https://tabakkatabacaria.com/wp-content/themes/kadence/assets/css/woocommerce.min.css?ver=1.2.9' media='all' />
<link rel='stylesheet' id='kadence-footer-css' href='https://tabakkatabacaria.com/wp-content/themes/kadence/assets/css/footer.min.css?ver=1.2.9' media='all' />
<link rel='stylesheet' id='jet-blocks-css' href='https://tabakkatabacaria.com/wp-content/uploads/elementor/css/custom-jet-blocks.css?ver=1.3.10' media='all' />
<link rel='stylesheet' id='jet-elements-css' href='https://tabakkatabacaria.com/wp-content/plugins/jet-elements/assets/css/jet-elements.css?ver=2.6.15' media='all' />
<link rel='stylesheet' id='jet-elements-skin-css' href='https://tabakkatabacaria.com/wp-content/plugins/jet-elements/assets/css/jet-elements-skin.css?ver=2.6.15' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.31.0' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' media='all' />
<link rel='stylesheet' id='e-swiper-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/conditionals/e-swiper.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='elementor-post-14-css' href='https://tabakkatabacaria.com/wp-content/uploads/elementor/css/post-14.css?ver=1726041380' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.20.1' media='all' />
<link rel='stylesheet' id='sbistyles-css' href='https://tabakkatabacaria.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=6.5.0' media='all' />
<link rel='stylesheet' id='elementor-post-1145-css' href='https://tabakkatabacaria.com/wp-content/uploads/elementor/css/post-1145.css?ver=1726041380' media='all' />
<link rel='stylesheet' id='jet-woo-builder-css' href='https://tabakkatabacaria.com/wp-content/plugins/jet-woo-builder/assets/css/frontend.css?ver=2.1.10' media='all' />
<style id='jet-woo-builder-inline-css'>
@font-face {
				font-family: "WooCommerce";
				font-weight: normal;
				font-style: normal;
				src: url("https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.eot");
				src: url("https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.eot?#iefix") format("embedded-opentype"),
					 url("https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.woff") format("woff"),
					 url("https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.ttf") format("truetype"),
					 url("https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.svg#WooCommerce") format("svg");
			}
</style>
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-post-1919-css' href='https://tabakkatabacaria.com/wp-content/uploads/elementor/css/post-1919.css?ver=1726041380' media='all' />
<link rel='stylesheet' id='elementor-post-22471-css' href='https://tabakkatabacaria.com/wp-content/uploads/elementor/css/post-22471.css?ver=1726041380' media='all' />
<link rel='stylesheet' id='elementor-post-1335-css' href='https://tabakkatabacaria.com/wp-content/uploads/elementor/css/post-1335.css?ver=1726041380' media='all' />
<link rel='stylesheet' id='awcfe-frontend-css' href='https://tabakkatabacaria.com/wp-content/plugins/checkout-field-editor-and-manager-for-woocommerce/assets/css/frontend.css?ver=2.2.23' media='all' />
<link rel='stylesheet' id='pedido-minimo-custom-styles-css' href='https://tabakkatabacaria.com/wp-content/plugins/wc-pedido-minimo/inc/assets/css/styles.css?ver=6.6.2' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://tabakkatabacaria.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=6.0.4' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.6.2' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script src="https://tabakkatabacaria.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://tabakkatabacaria.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.9.3.1" id="jquery-blockui-js" data-wp-strategy="defer"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.9.3.1" id="js-cookie-js" defer data-wp-strategy="defer"></script>
<script id="woocommerce-js-extra">
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=9.3.1" id="woocommerce-js" defer data-wp-strategy="defer"></script>

<!-- Snippet da tag do Google (gtag.js) adicionado pelo Site Kit -->

<!-- Snippet do Google Analytics adicionado pelo Site Kit -->
<script src="https://www.googletagmanager.com/gtag/js?id=GT-NFR3QSHW" id="google_gtagjs-js" async></script>
<script id="google_gtagjs-js-after">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["tabakkatabacaria.com"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "GT-NFR3QSHW");
</script>

<!-- Fim do snippet da tag do Google (gtag.js) adicionado pelo Site Kit -->
<link rel="https://api.w.org/" href="https://tabakkatabacaria.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://tabakkatabacaria.com/xmlrpc.php?rsd" />

<meta name="generator" content="Site Kit by Google 1.135.0" />		<style>
			.dgwt-wcas-ico-magnifier,.dgwt-wcas-ico-magnifier-handler{max-width:20px}		</style>
			<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.24.0; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '438521482416147');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=438521482416147&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<script>
!function (w, d, t) {
  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};

  ttq.load('CP1S1E3C77UBF4EEO210');
  ttq.page();
}(window, document, 'ttq');
</script>
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<style id='wp-fonts-local'>
@font-face{font-family:Inter;font-style:normal;font-weight:300 900;font-display:fallback;src:url('https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/Inter-VariableFont_slnt,wght.woff2') format('woff2');font-stretch:normal;}
@font-face{font-family:Cardo;font-style:normal;font-weight:400;font-display:fallback;src:url('https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/fonts/cardo_normal_400.woff2') format('woff2');}
</style>
<link rel="icon" href="https://tabakkatabacaria.com/wp-content/uploads/2022/05/cropped-tabakka-tabacaria-32x32.png" sizes="32x32" />
<link rel="icon" href="https://tabakkatabacaria.com/wp-content/uploads/2022/05/cropped-tabakka-tabacaria-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://tabakkatabacaria.com/wp-content/uploads/2022/05/cropped-tabakka-tabacaria-180x180.png" />
<meta name="msapplication-TileImage" content="https://tabakkatabacaria.com/wp-content/uploads/2022/05/cropped-tabakka-tabacaria-270x270.png" />
		<style id="wp-custom-css">
			/* Remover espaço em brando lateral no mobile */
html, body{
    overflow-x: hidden !important; 
}

/*aumentar ico search*/
.dgwt-wcas-search-icon {
    width: 38px;
}

/*remover bkg bag*/
.elementor-button-wrapper .elementor-button:hover, .elementor-button-wrapper .elementor-button:focus, .elementor-button-wrapper .elementor-button:active {
    background-color: #185abc00;
	}

/*alinhar pagseguro (1 por linha)*/
.woocommerce form .form-row-first, .woocommerce form .form-row-last, .woocommerce-page form .form-row-first, .woocommerce-page form .form-row-last {
    width: 100%;
}

/*alinhar radio frete*/
.woocommerce ul#shipping_method li {
    margin: 0 0 0.5em;
    line-height: 1.5em;
    list-style: none outside;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
}		</style>
		</head>

<body class="error404 wp-custom-logo wp-embed-responsive theme-kadence woocommerce-no-js woo-variation-swatches wvs-behavior-blur wvs-theme-kadence-child wvs-show-label hfeed footer-on-bottom hide-focus-outline link-style-standard content-title-style-normal content-width-normal content-style-boxed content-vertical-padding-show non-transparent-header mobile-non-transparent-header kadence-elementor-colors elementor-default elementor-kit-14">
<div id="wrapper" class="site wp-site-blocks">
			<a class="skip-link screen-reader-text scroll-ignore" href="#main">Pular para o Conteúdo</a>
				<div data-elementor-type="header" data-elementor-id="1145" class="elementor elementor-1145 elementor-location-header" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-d3bf1dd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d3bf1dd" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[],&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-11b78af" data-id="11b78af" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-6b06f7b elementor-widget elementor-widget-heading" data-id="6b06f7b" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default"><strong>ENTREGAS VIA MOTOBOY DE SEG À SEX:</strong> PEDIDOS CONFIRMADOS ATÉ AS 13h, SÃO ENTREGUES NO MESMO DIA. </h2>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-a33739d elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a33739d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3fd57cb" data-id="3fd57cb" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-afa61ce elementor-widget elementor-widget-heading" data-id="afa61ce" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Distribuidora de vapes, pods e acessórios para narguilé. Pedido mínimo de R$500,00.</h2>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-de938a8" data-id="de938a8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d415bf7 elementor-position-left elementor-vertical-align-middle elementor-view-default elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="d415bf7" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="https://wa.me/+551133135282" target="_blank" class="elementor-icon elementor-animation-" tabindex="-1">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="https://wa.me/+551133135282" target="_blank" >
							WhatsApp						</a>
					</h3>
				
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-e56fcbc" data-id="e56fcbc" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-c5c0898 elementor-position-left elementor-vertical-align-middle elementor-view-default elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="c5c0898" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="https://www.instagram.com/tabakkatabacariaa/" target="_blank" class="elementor-icon elementor-animation-" tabindex="-1">
				<i aria-hidden="true" class="fab fa-instagram"></i>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="https://www.instagram.com/tabakkatabacariaa/" target="_blank" >
							Instagram						</a>
					</h3>
				
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-9f0b0fa elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9f0b0fa" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;],&quot;jet_parallax_layout_list&quot;:[],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-de78d00" data-id="de78d00" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-8f5e4b2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8f5e4b2" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c3b6e92" data-id="c3b6e92" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-cc366ab elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="cc366ab" data-element_type="widget" data-widget_type="theme-site-logo.default">
				<div class="elementor-widget-container">
									<a href="https://tabakkatabacaria.com">
			<img fetchpriority="high" width="300" height="169" src="https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria.png" class="attachment-full size-full wp-image-1142" alt="" srcset="https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria.png 300w, https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria-64x36.png 64w" sizes="(max-width: 300px) 100vw, 300px" />				</a>
									</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-15f69cb" data-id="15f69cb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f378756 elementor-widget elementor-widget-shortcode" data-id="f378756" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode"><div  class="dgwt-wcas-search-wrapp dgwt-wcas-no-submit woocommerce dgwt-wcas-style-solaris js-dgwt-wcas-layout-classic dgwt-wcas-layout-classic js-dgwt-wcas-mobile-overlay-enabled">
		<form class="dgwt-wcas-search-form" role="search" action="https://tabakkatabacaria.com/" method="get">
		<div class="dgwt-wcas-sf-wrapp">
			<img class="dgwt-wcas-ico-magnifier"src="https://tabakkatabacaria.com/wp-content/uploads/2022/05/search.png" alt="Search icon" width="70" height="70" />			<label class="screen-reader-text"
				   for="dgwt-wcas-search-input-1">Pesquisar produtos</label>

			<input id="dgwt-wcas-search-input-1"
				   type="search"
				   class="dgwt-wcas-search-input"
				   name="s"
				   value=""
				   placeholder="Pesquise seu produto..."
				   autocomplete="off"
							/>
			<div class="dgwt-wcas-preloader"></div>

			<div class="dgwt-wcas-voice-search"></div>

			
			<input type="hidden" name="post_type" value="product"/>
			<input type="hidden" name="dgwt_wcas" value="1"/>

			
					</div>
	</form>
</div>
</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-e30ec76" data-id="e30ec76" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-68468be elementor-view-default elementor-widget elementor-widget-icon" data-id="68468be" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="https://tabakkatabacaria.com/minha-conta/">
			<i aria-hidden="true" class="fas fa-user"></i>			</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-a14c605" data-id="a14c605" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-22fec43 elementor-view-default elementor-widget elementor-widget-icon" data-id="22fec43" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="https://tabakkatabacaria.com/carrinho/">
			<i aria-hidden="true" class="fas fa-shopping-cart"></i>			</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-f4c887f toggle-icon--bag-medium elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile elementor-menu-cart--items-indicator-bubble elementor-menu-cart--cart-type-side-cart elementor-menu-cart--show-remove-button-yes elementor-widget elementor-widget-woocommerce-menu-cart" data-id="f4c887f" data-element_type="widget" data-settings="{&quot;cart_type&quot;:&quot;side-cart&quot;,&quot;open_cart&quot;:&quot;click&quot;}" data-widget_type="woocommerce-menu-cart.default">
				<div class="elementor-widget-container">
					<div class="elementor-menu-cart__wrapper">
							<div class="elementor-menu-cart__toggle_wrapper">
					<div class="elementor-menu-cart__container elementor-lightbox" aria-hidden="true">
						<div class="elementor-menu-cart__main" aria-hidden="true">
									<div class="elementor-menu-cart__close-button">
					</div>
									<div class="widget_shopping_cart_content">
															</div>
						</div>
					</div>
							<div class="elementor-menu-cart__toggle elementor-button-wrapper">
			<a id="elementor-menu-cart__toggle_button" href="#" class="elementor-menu-cart__toggle_button elementor-button elementor-size-sm" aria-expanded="false">
				<span class="elementor-button-text"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#82;&#36;</span>0,00</bdi></span></span>
				<span class="elementor-button-icon">
					<span class="elementor-button-icon-qty" data-counter="0">0</span>
					<i class="eicon-bag-medium"></i>					<span class="elementor-screen-only">Cart</span>
				</span>
			</a>
		</div>
						</div>
					</div> <!-- close elementor-menu-cart__wrapper -->
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-3ec72f7 elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3ec72f7" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-477c7d5" data-id="477c7d5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9a1d5ff elementor-nav-menu__align-center elementor-nav-menu--dropdown-none elementor-widget elementor-widget-nav-menu" data-id="9a1d5ff" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;horizontal&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-caret-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;}}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none">
				<ul id="menu-1-9a1d5ff" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1975"><a href="https://tabakkatabacaria.com/loja/" class="elementor-item">Loja</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-23437"><a href="https://tabakkatabacaria.com/categoria-produto/perfumes/" class="elementor-item">Perfumes</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2224"><a href="https://tabakkatabacaria.com/categoria-produto/vape/" class="elementor-item">Vape</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2222"><a href="https://tabakkatabacaria.com/categoria-produto/pod-system/" class="elementor-item">Pod System</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2220"><a href="https://tabakkatabacaria.com/categoria-produto/descartavel/" class="elementor-item">Descartável</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2475"><a href="https://tabakkatabacaria.com/categoria-produto/liquido/" class="elementor-item">Líquido</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2221"><a href="https://tabakkatabacaria.com/categoria-produto/narguile/" class="elementor-item">Narguile</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2223"><a href="https://tabakkatabacaria.com/categoria-produto/tabacaria/" class="elementor-item">Tabacaria</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2219"><a href="https://tabakkatabacaria.com/categoria-produto/acessorios/" class="elementor-item">Acessórios</a></li>
</ul>			</nav>
						<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-9a1d5ff" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1975"><a href="https://tabakkatabacaria.com/loja/" class="elementor-item" tabindex="-1">Loja</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-23437"><a href="https://tabakkatabacaria.com/categoria-produto/perfumes/" class="elementor-item" tabindex="-1">Perfumes</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2224"><a href="https://tabakkatabacaria.com/categoria-produto/vape/" class="elementor-item" tabindex="-1">Vape</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2222"><a href="https://tabakkatabacaria.com/categoria-produto/pod-system/" class="elementor-item" tabindex="-1">Pod System</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2220"><a href="https://tabakkatabacaria.com/categoria-produto/descartavel/" class="elementor-item" tabindex="-1">Descartável</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2475"><a href="https://tabakkatabacaria.com/categoria-produto/liquido/" class="elementor-item" tabindex="-1">Líquido</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2221"><a href="https://tabakkatabacaria.com/categoria-produto/narguile/" class="elementor-item" tabindex="-1">Narguile</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2223"><a href="https://tabakkatabacaria.com/categoria-produto/tabacaria/" class="elementor-item" tabindex="-1">Tabacaria</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2219"><a href="https://tabakkatabacaria.com/categoria-produto/acessorios/" class="elementor-item" tabindex="-1">Acessórios</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-d6dd88e elementor-hidden-desktop elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d6dd88e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;mobile&quot;],&quot;jet_parallax_layout_list&quot;:[],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-e39721e" data-id="e39721e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-df0989d elementor-view-default elementor-widget elementor-widget-icon" data-id="df0989d" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjEzMzUiLCJ0b2dnbGUiOmZhbHNlfQ%3D%3D">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:cc="http://creativecommons.org/ns#" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" xmlns:svg="http://www.w3.org/2000/svg" height="32" id="svg2" viewBox="0 0 32 32" width="32" xml:space="preserve"><defs id="defs6"></defs><g id="g10" transform="matrix(1.3333333,0,0,-1.3333333,0,32)"><path d="M 6.4124,16.292783 H 18.411669" id="path168" style="fill:#ffffff;stroke:#ffffff;stroke-width:0.77399999;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"></path><path d="m 6.4124,12.110025 h 8.205209" id="path170" style="fill:#ffffff;stroke:#ffffff;stroke-width:0.77399999;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"></path><path d="m 6.4124,7.9272666 h 4.424821" id="path981" style="fill:#ffffff;stroke:#ffffff;stroke-width:0.77399999;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"></path></g></svg>			</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-c2c4e1f" data-id="c2c4e1f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-46de68b elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="46de68b" data-element_type="widget" data-widget_type="theme-site-logo.default">
				<div class="elementor-widget-container">
									<a href="https://tabakkatabacaria.com">
			<img fetchpriority="high" width="300" height="169" src="https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria.png" class="attachment-full size-full wp-image-1142" alt="" srcset="https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria.png 300w, https://tabakkatabacaria.com/wp-content/uploads/2022/05/tabakka-tabacaria-64x36.png 64w" sizes="(max-width: 300px) 100vw, 300px" />				</a>
									</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-557b14d" data-id="557b14d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-99aa172 elementor-widget elementor-widget-wp-widget-dgwt_wcas_ajax_search" data-id="99aa172" data-element_type="widget" data-widget_type="wp-widget-dgwt_wcas_ajax_search.default">
				<div class="elementor-widget-container">
			<div class="woocommerce dgwt-wcas-widget"><div  class="dgwt-wcas-search-wrapp dgwt-wcas-no-submit woocommerce dgwt-wcas-style-solaris js-dgwt-wcas-layout-icon dgwt-wcas-layout-icon js-dgwt-wcas-mobile-overlay-enabled">
			<div  class="dgwt-wcas-search-icon js-dgwt-wcas-search-icon-handler"><img loading="lazy" class="dgwt-wcas-ico-magnifier-handler"src="https://tabakkatabacaria.com/wp-content/uploads/2022/05/search.png" alt="Search icon" width="70" height="70" /></div>
		<div class="dgwt-wcas-search-icon-arrow"></div>
		<form class="dgwt-wcas-search-form" role="search" action="https://tabakkatabacaria.com/" method="get">
		<div class="dgwt-wcas-sf-wrapp">
			<img class="dgwt-wcas-ico-magnifier"src="https://tabakkatabacaria.com/wp-content/uploads/2022/05/search.png" alt="Search icon" width="70" height="70" />			<label class="screen-reader-text"
				   for="dgwt-wcas-search-input-2">Pesquisar produtos</label>

			<input id="dgwt-wcas-search-input-2"
				   type="search"
				   class="dgwt-wcas-search-input"
				   name="s"
				   value=""
				   placeholder="Pesquise seu produto..."
				   autocomplete="off"
							/>
			<div class="dgwt-wcas-preloader"></div>

			<div class="dgwt-wcas-voice-search"></div>

			
			<input type="hidden" name="post_type" value="product"/>
			<input type="hidden" name="dgwt_wcas" value="1"/>

			
					</div>
	</form>
</div>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-94f50a2" data-id="94f50a2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d4734c0 toggle-icon--bag-medium elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile elementor-menu-cart--items-indicator-bubble elementor-menu-cart--cart-type-side-cart elementor-menu-cart--show-remove-button-yes elementor-widget elementor-widget-woocommerce-menu-cart" data-id="d4734c0" data-element_type="widget" data-settings="{&quot;cart_type&quot;:&quot;side-cart&quot;,&quot;open_cart&quot;:&quot;click&quot;}" data-widget_type="woocommerce-menu-cart.default">
				<div class="elementor-widget-container">
					<div class="elementor-menu-cart__wrapper">
							<div class="elementor-menu-cart__toggle_wrapper">
					<div class="elementor-menu-cart__container elementor-lightbox" aria-hidden="true">
						<div class="elementor-menu-cart__main" aria-hidden="true">
									<div class="elementor-menu-cart__close-button">
					</div>
									<div class="widget_shopping_cart_content">
															</div>
						</div>
					</div>
							<div class="elementor-menu-cart__toggle elementor-button-wrapper">
			<a id="elementor-menu-cart__toggle_button" href="#" class="elementor-menu-cart__toggle_button elementor-button elementor-size-sm" aria-expanded="false">
				<span class="elementor-button-text"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#82;&#36;</span>0,00</bdi></span></span>
				<span class="elementor-button-icon">
					<span class="elementor-button-icon-qty" data-counter="0">0</span>
					<i class="eicon-bag-medium"></i>					<span class="elementor-screen-only">Cart</span>
				</span>
			</a>
		</div>
						</div>
					</div> <!-- close elementor-menu-cart__wrapper -->
				</div>
				</div>
				<div class="elementor-element elementor-element-6564560 elementor-view-default elementor-widget elementor-widget-icon" data-id="6564560" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="https://tabakkatabacaria.com/carrinho/">
			<i aria-hidden="true" class="fas fa-shopping-cart"></i>			</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-aa937de elementor-hidden-desktop elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="aa937de" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[],&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c7fff3f" data-id="c7fff3f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-04d65d9 elementor-widget elementor-widget-heading" data-id="04d65d9" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">PEDIDO MÍNIMO DE R$500,00.</h2>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		
	<div id="inner-wrap" class="wrap hfeed kt-clear">
		<div id="primary" class="content-area">
	<div class="content-container site-container">
		<main id="main" class="site-main" role="main">
			<div class="woocommerce kadence-woo-messages-none-woo-pages woocommerce-notices-wrapper"></div>			<div class="content-wrap">
				<section class="error">

	<div class="page-content entry content-bg">

		<div class="entry-content-wrap">

				<header class="page-header">
		<h1 class="page-title">
			Oops! Página Não Encontrada.		</h1>
	</header><!-- .page-header -->
				<p>
				Parece que nada foi encontrado neste Local. Talvez tente uma Pesquisa?			</p>

			<form role="search" method="get" class="search-form" action="https://tabakkatabacaria.com/">
				<label>
					<span class="screen-reader-text">Pesquisar por:</span>
					<input type="search" class="search-field" placeholder="Pesquisar &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Pesquisar" />
			<div class="kadence-search-icon-wrap"><span class="kadence-svg-iconset"><svg aria-hidden="true" class="kadence-svg-icon kadence-search-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="26" height="28" viewBox="0 0 26 28"><title>Pesquisa</title><path d="M18 13c0-3.859-3.141-7-7-7s-7 3.141-7 7 3.141 7 7 7 7-3.141 7-7zM26 26c0 1.094-0.906 2-2 2-0.531 0-1.047-0.219-1.406-0.594l-5.359-5.344c-1.828 1.266-4.016 1.937-6.234 1.937-6.078 0-11-4.922-11-11s4.922-11 11-11 11 4.922 11 11c0 2.219-0.672 4.406-1.937 6.234l5.359 5.359c0.359 0.359 0.578 0.875 0.578 1.406z"></path>
				</svg></span></div></form>		</div>
	</div><!-- .page-content -->
</section><!-- .error -->
			</div>
					</main><!-- #main -->
			</div>
</div><!-- #primary -->
	</div><!-- #inner-wrap -->
			<div data-elementor-type="footer" data-elementor-id="1919" class="elementor elementor-1919 elementor-location-footer" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-54a7e4c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="54a7e4c" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b24b8ed" data-id="b24b8ed" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-abfb441 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="abfb441" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-43b9022" data-id="43b9022" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9f997a7 elementor-widget elementor-widget-heading" data-id="9f997a7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">MENU</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-0ff29ea elementor-nav-menu__align-start elementor-nav-menu--dropdown-none elementor-widget elementor-widget-nav-menu" data-id="0ff29ea" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;vertical&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-caret-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;}}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-vertical e--pointer-none">
				<ul id="menu-1-0ff29ea" class="elementor-nav-menu sm-vertical"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1975"><a href="https://tabakkatabacaria.com/loja/" class="elementor-item">Loja</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-23437"><a href="https://tabakkatabacaria.com/categoria-produto/perfumes/" class="elementor-item">Perfumes</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2224"><a href="https://tabakkatabacaria.com/categoria-produto/vape/" class="elementor-item">Vape</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2222"><a href="https://tabakkatabacaria.com/categoria-produto/pod-system/" class="elementor-item">Pod System</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2220"><a href="https://tabakkatabacaria.com/categoria-produto/descartavel/" class="elementor-item">Descartável</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2475"><a href="https://tabakkatabacaria.com/categoria-produto/liquido/" class="elementor-item">Líquido</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2221"><a href="https://tabakkatabacaria.com/categoria-produto/narguile/" class="elementor-item">Narguile</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2223"><a href="https://tabakkatabacaria.com/categoria-produto/tabacaria/" class="elementor-item">Tabacaria</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2219"><a href="https://tabakkatabacaria.com/categoria-produto/acessorios/" class="elementor-item">Acessórios</a></li>
</ul>			</nav>
						<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-0ff29ea" class="elementor-nav-menu sm-vertical"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1975"><a href="https://tabakkatabacaria.com/loja/" class="elementor-item" tabindex="-1">Loja</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-23437"><a href="https://tabakkatabacaria.com/categoria-produto/perfumes/" class="elementor-item" tabindex="-1">Perfumes</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2224"><a href="https://tabakkatabacaria.com/categoria-produto/vape/" class="elementor-item" tabindex="-1">Vape</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2222"><a href="https://tabakkatabacaria.com/categoria-produto/pod-system/" class="elementor-item" tabindex="-1">Pod System</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2220"><a href="https://tabakkatabacaria.com/categoria-produto/descartavel/" class="elementor-item" tabindex="-1">Descartável</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2475"><a href="https://tabakkatabacaria.com/categoria-produto/liquido/" class="elementor-item" tabindex="-1">Líquido</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2221"><a href="https://tabakkatabacaria.com/categoria-produto/narguile/" class="elementor-item" tabindex="-1">Narguile</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2223"><a href="https://tabakkatabacaria.com/categoria-produto/tabacaria/" class="elementor-item" tabindex="-1">Tabacaria</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2219"><a href="https://tabakkatabacaria.com/categoria-produto/acessorios/" class="elementor-item" tabindex="-1">Acessórios</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-32a74b8" data-id="32a74b8" data-element_type="column">
			<div class="elementor-widget-wrap">
							</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6a14ebf" data-id="6a14ebf" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f62f1fa elementor-widget elementor-widget-heading" data-id="f62f1fa" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">ATENDIMENTO</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-f7d8a52 elementor-widget elementor-widget-text-editor" data-id="f7d8a52" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Segunda a sexta, das 09:00 às 17:00.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-55375c8 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="55375c8" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://wa.me/+551133135282">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-whatsapp"></i>						</span>
										<span class="elementor-icon-list-text">(11) 3313-5282</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-e7dbf1f elementor-widget elementor-widget-heading" data-id="e7dbf1f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">INFORMAÇÕES</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-4a8fea3 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="4a8fea3" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://tabakkatabacaria.com/politica-de-trocas-e-devolucoes/">

											<span class="elementor-icon-list-text">Política de Trocas e Devoluções</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tabakkatabacaria.com/politica-de-privacidade/">

											<span class="elementor-icon-list-text">Política de Privacidade</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4d9d0ac" data-id="4d9d0ac" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-983e368 elementor-widget elementor-widget-heading" data-id="983e368" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">COMPRA SEGURA</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-b38f4a5 elementor-widget elementor-widget-image" data-id="b38f4a5" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" width="622" height="327" src="https://tabakkatabacaria.com/wp-content/uploads/2022/05/compra-segura.png" class="attachment-large size-large wp-image-2011" alt="" srcset="https://tabakkatabacaria.com/wp-content/uploads/2022/05/compra-segura.png 622w, https://tabakkatabacaria.com/wp-content/uploads/2022/05/compra-segura-64x34.png 64w, https://tabakkatabacaria.com/wp-content/uploads/2022/05/compra-segura-300x158.png 300w" sizes="(max-width: 622px) 100vw, 622px" />													</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4041f6c elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="4041f6c" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f133c6f" data-id="f133c6f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-712409e elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="712409e" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-0b692e2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0b692e2" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-bc8c769" data-id="bc8c769" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-19b90fe elementor-widget elementor-widget-text-editor" data-id="19b90fe" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>© 2024 Todos os direitos reservados a Tabakka Tabacaria | Desenvolvido por <span style="text-decoration: underline;"><span style="color: #ffffff;"><a style="color: #ffffff; text-decoration: underline;" href="https://webmastersites.com.br">Web Master Sites</a></span></span></p>						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div><!-- #wrapper -->

			<script>document.documentElement.style.setProperty('--scrollbar-offset', window.innerWidth - document.documentElement.clientWidth + 'px' );</script>
			<!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://tabakkatabacaria.com/wp-admin/admin-ajax.php";
</script>
		<div data-elementor-type="popup" data-elementor-id="1335" class="elementor elementor-1335 elementor-location-popup" data-elementor-settings="{&quot;entrance_animation&quot;:&quot;none&quot;,&quot;entrance_animation_tablet&quot;:&quot;none&quot;,&quot;entrance_animation_mobile&quot;:&quot;fadeInLeft&quot;,&quot;exit_animation&quot;:&quot;none&quot;,&quot;exit_animation_tablet&quot;:&quot;none&quot;,&quot;exit_animation_mobile&quot;:&quot;fadeInLeft&quot;,&quot;entrance_animation_duration&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0.299999999999999988897769753748434595763683319091796875,&quot;sizes&quot;:[]},&quot;prevent_scroll&quot;:&quot;yes&quot;,&quot;avoid_multiple_popups&quot;:&quot;yes&quot;,&quot;close_button_position&quot;:&quot;outside&quot;,&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-9980421 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9980421" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b675bff" data-id="b675bff" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-ac5403a elementor-widget elementor-widget-spacer" data-id="ac5403a" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-715c396 elementor-mobile-position-left elementor-view-default elementor-position-top elementor-widget elementor-widget-icon-box" data-id="715c396" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="https://www.instagram.com/tabakkatabacariaa/" class="elementor-icon elementor-animation-" tabindex="-1">
				<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="800" width="1200" viewBox="-19.5036 -32.49725 169.0312 194.9835"><defs><radialGradient fy="578.088" fx="158.429" gradientTransform="matrix(0 -1.98198 1.8439 0 -1031.399 454.004)" gradientUnits="userSpaceOnUse" xlink:href="#a" r="65" cy="578.088" cx="158.429" id="c"></radialGradient><radialGradient fy="473.455" fx="147.694" gradientTransform="matrix(.17394 .86872 -3.5818 .71718 1648.351 -458.493)" gradientUnits="userSpaceOnUse" xlink:href="#b" r="65" cy="473.455" cx="147.694" id="d"></radialGradient><linearGradient id="b"><stop stop-color="#3771c8" offset="0"></stop><stop offset=".128" stop-color="#3771c8"></stop><stop stop-opacity="0" stop-color="#60f" offset="1"></stop></linearGradient><linearGradient id="a"><stop stop-color="#fd5" offset="0"></stop><stop stop-color="#fd5" offset=".1"></stop><stop stop-color="#ff543e" offset=".5"></stop><stop stop-color="#c837ab" offset="1"></stop></linearGradient></defs><path d="M65.033 0C37.891 0 29.953.028 28.41.156c-5.57.463-9.036 1.34-12.812 3.22-2.91 1.445-5.205 3.12-7.47 5.468-4.125 4.282-6.625 9.55-7.53 15.812-.44 3.04-.568 3.66-.594 19.188-.01 5.176 0 11.988 0 21.125 0 27.12.03 35.05.16 36.59.45 5.42 1.3 8.83 3.1 12.56 3.44 7.14 10.01 12.5 17.75 14.5 2.68.69 5.64 1.07 9.44 1.25 1.61.07 18.02.12 34.44.12 16.42 0 32.84-.02 34.41-.1 4.4-.207 6.955-.55 9.78-1.28a27.22 27.22 0 0017.75-14.53c1.765-3.64 2.66-7.18 3.065-12.317.088-1.12.125-18.977.125-36.81 0-17.836-.04-35.66-.128-36.78-.41-5.22-1.305-8.73-3.127-12.44-1.495-3.037-3.155-5.305-5.565-7.624-4.3-4.108-9.56-6.608-15.829-7.512C102.338.157 101.733.027 86.193 0z" fill="url(#c)"></path><path d="M65.033 0C37.891 0 29.953.028 28.41.156c-5.57.463-9.036 1.34-12.812 3.22-2.91 1.445-5.205 3.12-7.47 5.468-4.125 4.282-6.625 9.55-7.53 15.812-.44 3.04-.568 3.66-.594 19.188-.01 5.176 0 11.988 0 21.125 0 27.12.03 35.05.16 36.59.45 5.42 1.3 8.83 3.1 12.56 3.44 7.14 10.01 12.5 17.75 14.5 2.68.69 5.64 1.07 9.44 1.25 1.61.07 18.02.12 34.44.12 16.42 0 32.84-.02 34.41-.1 4.4-.207 6.955-.55 9.78-1.28a27.22 27.22 0 0017.75-14.53c1.765-3.64 2.66-7.18 3.065-12.317.088-1.12.125-18.977.125-36.81 0-17.836-.04-35.66-.128-36.78-.41-5.22-1.305-8.73-3.127-12.44-1.495-3.037-3.155-5.305-5.565-7.624-4.3-4.108-9.56-6.608-15.829-7.512C102.338.157 101.733.027 86.193 0z" fill="url(#d)"></path><path d="M65.003 17c-13.036 0-14.672.057-19.792.29-5.11.234-8.598 1.043-11.65 2.23-3.157 1.226-5.835 2.866-8.503 5.535-2.67 2.668-4.31 5.346-5.54 8.502-1.19 3.053-2 6.542-2.23 11.65C17.06 50.327 17 51.964 17 65s.058 14.667.29 19.787c.235 5.11 1.044 8.598 2.23 11.65 1.227 3.157 2.867 5.835 5.536 8.503 2.667 2.67 5.345 4.314 8.5 5.54 3.054 1.187 6.543 1.996 11.652 2.23 5.12.233 6.755.29 19.79.29 13.037 0 14.668-.057 19.788-.29 5.11-.234 8.602-1.043 11.656-2.23 3.156-1.226 5.83-2.87 8.497-5.54 2.67-2.668 4.31-5.346 5.54-8.502 1.18-3.053 1.99-6.542 2.23-11.65.23-5.12.29-6.752.29-19.788 0-13.036-.06-14.672-.29-19.792-.24-5.11-1.05-8.598-2.23-11.65-1.23-3.157-2.87-5.835-5.54-8.503-2.67-2.67-5.34-4.31-8.5-5.535-3.06-1.187-6.55-1.996-11.66-2.23-5.12-.233-6.75-.29-19.79-.29zm-4.306 8.65c1.278-.002 2.704 0 4.306 0 12.816 0 14.335.046 19.396.276 4.68.214 7.22.996 8.912 1.653 2.24.87 3.837 1.91 5.516 3.59 1.68 1.68 2.72 3.28 3.592 5.52.657 1.69 1.44 4.23 1.653 8.91.23 5.06.28 6.58.28 19.39s-.05 14.33-.28 19.39c-.214 4.68-.996 7.22-1.653 8.91-.87 2.24-1.912 3.835-3.592 5.514-1.68 1.68-3.275 2.72-5.516 3.59-1.69.66-4.232 1.44-8.912 1.654-5.06.23-6.58.28-19.396.28-12.817 0-14.336-.05-19.396-.28-4.68-.216-7.22-.998-8.913-1.655-2.24-.87-3.84-1.91-5.52-3.59-1.68-1.68-2.72-3.276-3.592-5.517-.657-1.69-1.44-4.23-1.653-8.91-.23-5.06-.276-6.58-.276-19.398s.046-14.33.276-19.39c.214-4.68.996-7.22 1.653-8.912.87-2.24 1.912-3.84 3.592-5.52 1.68-1.68 3.28-2.72 5.52-3.592 1.692-.66 4.233-1.44 8.913-1.655 4.428-.2 6.144-.26 15.09-.27zm29.928 7.97a5.76 5.76 0 105.76 5.758c0-3.18-2.58-5.76-5.76-5.76zm-25.622 6.73c-13.613 0-24.65 11.037-24.65 24.65 0 13.613 11.037 24.645 24.65 24.645C78.616 89.645 89.65 78.613 89.65 65S78.615 40.35 65.002 40.35zm0 8.65c8.836 0 16 7.163 16 16 0 8.836-7.164 16-16 16-8.837 0-16-7.164-16-16 0-8.837 7.163-16 16-16z" fill="#fff"></path></svg>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="https://www.instagram.com/tabakkatabacariaa/" >
							Siga no Instagram						</a>
					</h3>
				
				
			</div>
			
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-a2177e6 elementor-mobile-position-left elementor-view-default elementor-position-top elementor-widget elementor-widget-icon-box" data-id="a2177e6" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="https://wa.me/+5511910918240" class="elementor-icon elementor-animation-" tabindex="-1">
				<svg xmlns="http://www.w3.org/2000/svg" height="800" width="1200" viewBox="-116.80905 -194.68125 1012.3451 1168.0875"><defs><linearGradient x1="0" y1="0" x2="1" y2="0" gradientUnits="userSpaceOnUse" gradientTransform="matrix(0 584.04474 584.04474 0 642 241.839)" spreadMethod="pad" id="a"><stop offset="0" stop-color="#25cf43"></stop><stop offset="1" stop-color="#61fd7d"></stop></linearGradient></defs><path d="M482.751 825.596c-13.025-.463-29.812-1.482-37.442-3.022-11.647-2.352-22.646-5.918-31.793-10.58-10.747-5.477-20.379-12.465-28.696-20.769-8.336-8.32-15.352-17.961-20.851-28.724-4.649-9.098-8.213-20.03-10.575-31.611-1.571-7.707-2.61-24.619-3.081-37.728a525.205 525.205 0 01-.289-15.49l-.046-287.576c0-3.185.097-10.121.287-15.485.463-13.024 1.482-29.811 3.023-37.441 2.351-11.646 5.918-22.646 10.579-31.793 5.478-10.748 12.465-20.378 20.769-28.696 8.32-8.335 17.962-15.351 28.724-20.851 9.099-4.648 20.031-8.213 31.611-10.575 7.707-1.571 24.62-2.61 37.729-3.08 5.356-.192 12.291-.29 15.489-.29l287.576-.046c3.186 0 10.122.096 15.484.287 13.025.464 29.813 1.482 37.442 3.023 11.647 2.352 22.647 5.919 31.793 10.579 10.747 5.478 20.379 12.466 28.696 20.769 8.335 8.321 15.351 17.961 20.851 28.724 4.648 9.099 8.214 20.03 10.575 31.611 1.572 7.707 2.61 24.621 3.081 37.729.192 5.357.289 12.291.289 15.489l.047 287.576c0 3.186-.097 10.122-.288 15.485-.464 13.024-1.482 29.811-3.023 37.441-2.351 11.647-5.918 22.646-10.579 31.793-5.477 10.748-12.466 20.379-20.768 28.697-8.321 8.334-17.963 15.351-28.725 20.85-9.099 4.649-20.03 8.214-31.611 10.575-7.707 1.571-24.62 2.61-37.728 3.08-5.358.193-12.292.29-15.49.29l-287.576.046a524.82 524.82 0 01-15.484-.287" fill="url(#a)" transform="matrix(1.33333 0 0 -1.33333 -466.637 1101.177)"></path><path d="M524.354 440.616c-6.936-3.47-41.036-20.245-47.395-22.558-6.357-2.314-10.98-3.471-15.604 3.47-4.624 6.942-17.916 22.559-21.963 27.187-4.045 4.627-8.09 5.207-15.026 1.735-6.936-3.47-29.284-10.792-55.776-34.415-20.62-18.384-34.54-41.092-38.586-48.033-4.045-6.942-.43-10.694 3.043-14.151 3.119-3.105 6.935-8.097 10.403-12.147 3.468-4.05 4.624-6.941 6.936-11.568 2.312-4.628 1.156-8.677-.58-12.148-1.732-3.47-15.603-37.598-21.383-51.481-5.63-13.52-11.348-11.69-15.605-11.903-4.042-.201-8.67-.244-13.294-.244-4.624 0-12.137 1.736-18.496 8.676-6.357 6.942-24.274 23.718-24.274 57.844 0 34.128 24.853 67.099 28.32 71.727 3.469 4.628 48.909 74.663 118.485 104.696 16.548 7.144 29.468 11.41 39.54 14.607 16.616 5.276 31.736 4.532 43.687 2.746 13.325-1.99 41.036-16.774 46.816-32.97 5.778-16.196 5.778-30.08 4.045-32.971-1.733-2.892-6.357-4.628-13.293-8.099M397.8 613.355h-.093c-41.4-.016-82.005-11.133-117.428-32.148l-8.425-5-87.322 22.9 23.308-85.11-5.486-8.726c-23.095-36.723-35.292-79.167-35.275-122.747.05-127.168 103.55-230.628 230.813-230.628 61.624.024 119.552 24.047 163.112 67.642 43.56 43.596 67.536 101.545 67.512 163.173-.052 127.177-103.55 230.644-230.716 230.644M594.158 186.41c-52.408-52.452-122.104-81.352-196.36-81.381-153 0-277.524 124.476-277.586 277.477-.02 48.908 12.762 96.65 37.052 138.73l-39.38 143.797 147.152-38.587c40.544 22.107 86.192 33.756 132.65 33.776h.116c152.985 0 277.52-124.492 277.582-277.495.028-74.146-28.817-143.866-81.226-196.317" fill="#fff" fill-rule="evenodd"></path></svg>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="https://wa.me/+5511910918240" >
							Atendimento						</a>
					</h3>
				
				
			</div>
			
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-1494a32 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="1494a32" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-9813350 elementor-mobile-position-left elementor-view-default elementor-position-top elementor-widget elementor-widget-icon-box" data-id="9813350" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="https://tabakkatabacaria.com/minha-conta/" class="elementor-icon elementor-animation-" tabindex="-1">
				<i aria-hidden="true" class="fas fa-user"></i>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="https://tabakkatabacaria.com/minha-conta/" >
							Minha conta						</a>
					</h3>
				
				
			</div>
			
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-0eea581 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="0eea581" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-15debdf elementor-widget elementor-widget-nav-menu" data-id="15debdf" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;dropdown&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-caret-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;}}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-15debdf" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1975"><a href="https://tabakkatabacaria.com/loja/" class="elementor-item" tabindex="-1">Loja</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-23437"><a href="https://tabakkatabacaria.com/categoria-produto/perfumes/" class="elementor-item" tabindex="-1">Perfumes</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2224"><a href="https://tabakkatabacaria.com/categoria-produto/vape/" class="elementor-item" tabindex="-1">Vape</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2222"><a href="https://tabakkatabacaria.com/categoria-produto/pod-system/" class="elementor-item" tabindex="-1">Pod System</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2220"><a href="https://tabakkatabacaria.com/categoria-produto/descartavel/" class="elementor-item" tabindex="-1">Descartável</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2475"><a href="https://tabakkatabacaria.com/categoria-produto/liquido/" class="elementor-item" tabindex="-1">Líquido</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2221"><a href="https://tabakkatabacaria.com/categoria-produto/narguile/" class="elementor-item" tabindex="-1">Narguile</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2223"><a href="https://tabakkatabacaria.com/categoria-produto/tabacaria/" class="elementor-item" tabindex="-1">Tabacaria</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2219"><a href="https://tabakkatabacaria.com/categoria-produto/acessorios/" class="elementor-item" tabindex="-1">Acessórios</a></li>
</ul>			</nav>
				</div>
				</div>
				<div class="elementor-element elementor-element-48e91a8 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="48e91a8" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-1c8c9c2 elementor-widget elementor-widget-nav-menu" data-id="1c8c9c2" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;dropdown&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-caret-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;}}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-1c8c9c2" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-22467"><a rel="privacy-policy" href="https://tabakkatabacaria.com/politica-de-privacidade/" class="elementor-item" tabindex="-1">Política de Privacidade</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22468"><a href="https://tabakkatabacaria.com/politica-de-trocas-e-devolucoes/" class="elementor-item" tabindex="-1">Política de Trocas e Devoluções</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
				<div data-elementor-type="popup" data-elementor-id="22471" class="elementor elementor-22471 elementor-location-popup" data-elementor-settings="{&quot;prevent_close_on_background_click&quot;:&quot;yes&quot;,&quot;prevent_close_on_esc_key&quot;:&quot;yes&quot;,&quot;prevent_scroll&quot;:&quot;yes&quot;,&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;triggers&quot;:{&quot;page_load_delay&quot;:2,&quot;page_load&quot;:&quot;yes&quot;},&quot;timing&quot;:{&quot;times_times&quot;:1,&quot;times_period&quot;:&quot;day&quot;,&quot;times_count&quot;:&quot;close&quot;,&quot;times&quot;:&quot;yes&quot;}}" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-28aa436 elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="28aa436" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[],&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c44249c" data-id="c44249c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-67eb1a0 elementor-widget elementor-widget-heading" data-id="67eb1a0" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">PROIBIDO PARA MENORES DE 18 ANOS!</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-d8eb344 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d8eb344" data-element_type="section" data-settings="{&quot;jet_parallax_layout_list&quot;:[]}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-2433a63" data-id="2433a63" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-665f867 elementor-align-justify elementor-widget elementor-widget-button" data-id="665f867" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://www.google.com.br/">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">TENHO MENOS QUE 18 ANOS</span>
					</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-521417d elementor-hidden-desktop elementor-hidden-tablet elementor-widget elementor-widget-spacer" data-id="521417d" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-e4e7dc3" data-id="e4e7dc3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-a64e694 elementor-align-justify elementor-widget elementor-widget-button" data-id="a64e694" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="#elementor-action%3Aaction%3Dpopup%3Aclose%26settings%3DeyJkb19ub3Rfc2hvd19hZ2FpbiI6IiJ9">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">TENHO 18 ANOS OU MAIS</span>
					</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
					<script type='text/javascript'>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
				<script>
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='wc-blocks-style-css' href='https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=wc-9.3.1' media='all' />
<link rel='stylesheet' id='widget-heading-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='widget-icon-box-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='widget-image-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='widget-text-editor-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-text-editor.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='widget-icon-list-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='widget-divider-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-divider.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='widget-spacer-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/css/widget-spacer.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='e-animation-fadeInLeft-css' href='https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/lib/animations/styles/fadeInLeft.min.css?ver=3.24.0' media='all' />
<script src="https://tabakkatabacaria.com/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script src="https://tabakkatabacaria.com/wp-includes/js/wp-util.min.js?ver=6.6.2" id="wp-util-js"></script>
<script id="wp-api-request-js-extra">
var wpApiSettings = {"root":"https:\/\/tabakkatabacaria.com\/wp-json\/","nonce":"3170e721da","versionString":"wp\/v2\/"};
</script>
<script src="https://tabakkatabacaria.com/wp-includes/js/api-request.min.js?ver=6.6.2" id="wp-api-request-js"></script>
<script src="https://tabakkatabacaria.com/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script src="https://tabakkatabacaria.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script src="https://tabakkatabacaria.com/wp-includes/js/dist/url.min.js?ver=36ae0e4dd9043bb8749b" id="wp-url-js"></script>
<script id="wp-api-fetch-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2024-09-08 22:00:15+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n > 1;","lang":"pt_BR"},"You are probably offline.":["Voc\u00ea provavelmente est\u00e1 offline."],"Media upload failed. If this is a photo or a large image, please scale it down and try again.":["Falha ao enviar a m\u00eddia. Se for uma foto ou imagem grande, reduza o tamanho e tente novamente."],"The response is not a valid JSON response.":["A resposta n\u00e3o \u00e9 um JSON v\u00e1lido."],"An unknown error occurred.":["Um erro desconhecido ocorreu."]}},"comment":{"reference":"wp-includes\/js\/dist\/api-fetch.js"}} );
</script>
<script src="https://tabakkatabacaria.com/wp-includes/js/dist/api-fetch.min.js?ver=4c185334c5ec26e149cc" id="wp-api-fetch-js"></script>
<script id="wp-api-fetch-js-after">
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://tabakkatabacaria.com/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "3170e721da" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://tabakkatabacaria.com/wp-admin/admin-ajax.php?action=rest-nonce";
</script>
<script src="https://tabakkatabacaria.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script id="woo-variation-swatches-js-extra">
var woo_variation_swatches_options = {"show_variation_label":"1","clear_on_reselect":"","variation_label_separator":":","is_mobile":"","show_variation_stock":"","stock_label_threshold":"5","cart_redirect_after_add":"no","enable_ajax_add_to_cart":"no","cart_url":"https:\/\/tabakkatabacaria.com\/carrinho\/","is_cart":""};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woo-variation-swatches/assets/js/frontend.min.js?ver=1725632304" id="woo-variation-swatches-js"></script>
<script id="woobt-frontend-js-extra">
var woobt_vars = {"ajax_url":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","add_to_cart_button":"main","position":"before","change_image":"yes","change_price":"yes","price_selector":".summary > .price","this_item":"yes","counter":"hide","variation_selector":"default","price_format":"%1$s%2$s","price_suffix":"","price_decimals":"2","price_thousand_separator":".","price_decimal_separator":",","currency_symbol":"R$","trim_zeros":"","additional_price_text":"Pre\u00e7o adicional","total_price_text":"Total:","add_to_cart":"Adicionar ao carrinho","alert_selection":"Selecione uma varia\u00e7\u00e3o para [name] antes de adicionar este produto ao carrinho."};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woo-bought-together-premium/assets/js/frontend.js?ver=5.1.1" id="woobt-frontend-js"></script>
<script id="woosb-frontend-js-extra">
var woosb_vars = {"price_decimals":"2","price_format":"%1$s%2$s","price_thousand_separator":".","price_decimal_separator":",","currency_symbol":"R$","trim_zeros":"","change_image":"yes","bundled_price":"no","bundled_price_from":"sale_price","change_price":"yes","price_selector":".summary > .price","saved_text":"(desconto de:[d])","price_text":"Pre\u00e7o do combo:","alert_selection":"Selecione uma varia\u00e7\u00e3o para [name] antes de adicionar este produto ao carrinho.","alert_empty":"Please choose at least one product before adding this bundle to the cart.","alert_min":"Please choose at least a total quantity of [min] products before adding this bundle to the cart.","alert_max":"Sorry, you can only choose at max a total quantity of [max] products before adding this bundle to the cart.","alert_total_min":"The total must meet the minimum amount of [min].","alert_total_max":"The total must meet the maximum amount of [max]."};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woo-product-bundle-premium/assets/js/frontend.js?ver=7.0.5" id="woosb-frontend-js"></script>
<script id="kadence-navigation-js-extra">
var kadenceConfig = {"screenReader":{"expand":"Menu filho","expandOf":"Meno filho do","collapse":"Menu filho","collapseOf":"Meno filho do"},"breakPoints":{"desktop":"1024","tablet":768},"scrollOffset":"0"};
</script>
<script src="https://tabakkatabacaria.com/wp-content/themes/kadence/assets/js/navigation.min.js?ver=1.2.9" id="kadence-navigation-js" async></script>
<script src="https://tabakkatabacaria.com/wp-content/themes/kadence/assets/js/shop-spinner.min.js?ver=1.2.9" id="kadence-shop-spinner-js" async></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=9.3.1" id="sourcebuster-js-js"></script>
<script id="wc-order-attribution-js-extra">
var wc_order_attribution = {"params":{"lifetime":1.0000000000000000818030539140313095458623138256371021270751953125e-5,"session":30,"base64":false,"ajaxurl":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","utm_source_platform":"current.plt","utm_creative_format":"current.fmt","utm_marketing_tactic":"current.tct","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=9.3.1" id="wc-order-attribution-js"></script>
<script id="eael-general-js-extra">
var localize = {"ajaxurl":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","nonce":"ae52926ab8","i18n":{"added":"Adicionado ","compare":"Comparar","loading":"Carregando..."},"eael_translate_text":{"required_text":"\u00e9 um campo obrigat\u00f3rio","invalid_text":"Inv\u00e1lido","billing_text":"Faturamento","shipping_text":"Envio","fg_mfp_counter_text":"de"},"page_permalink":"","cart_redirectition":"no","cart_page_url":"https:\/\/tabakkatabacaria.com\/carrinho\/","el_breakpoints":{"mobile":{"label":"Dispositivos m\u00f3veis no modo retrato","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Dispositivos m\u00f3veis no modo paisagem","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet no modo retrato","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet no modo paisagem","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Notebook","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Tela ampla (widescreen)","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=6.0.4" id="eael-general-js"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.2.1" id="smartmenus-js"></script>
<script id="jquery-dgwt-wcas-js-extra">
var dgwt_wcas = {"labels":{"post":"Post","page":"Page","vendor":"Fornecedor","product_plu":"Produtos","post_plu":"Posts","page_plu":"P\u00e1ginas","vendor_plu":"Fornecedores","sku_label":"SKU:","sale_badge":"Oferta","vendor_sold_by":"Vendido por:","featured_badge":"Destaque","in":"em","read_more":"continue lendo","no_results":"\"Nenhum resultado\"","no_results_default":"Nenhum resultado","show_more":"Ver todos os produtos...","show_more_details":"Ver todos os produtos...","search_placeholder":"Pesquise seu produto...","submit":"Pesquisa","search_hist":"Seu hist\u00f3rico de pesquisa","search_hist_clear":"Limpar","tax_product_cat_plu":"Categorias","tax_product_cat":"Categoria","tax_product_tag_plu":"Tags","tax_product_tag":"Tag"},"ajax_search_endpoint":"\/?wc-ajax=dgwt_wcas_ajax_search","ajax_details_endpoint":"\/?wc-ajax=dgwt_wcas_result_details","ajax_prices_endpoint":"\/?wc-ajax=dgwt_wcas_get_prices","action_search":"dgwt_wcas_ajax_search","action_result_details":"dgwt_wcas_result_details","action_get_prices":"dgwt_wcas_get_prices","min_chars":"3","width":"auto","show_details_panel":"","show_images":"1","show_price":"","show_desc":"","show_sale_badge":"","show_featured_badge":"","dynamic_prices":"","is_rtl":"","show_preloader":"1","show_headings":"1","preloader_url":"","taxonomy_brands":"","img_url":"https:\/\/tabakkatabacaria.com\/wp-content\/plugins\/ajax-search-for-woocommerce\/assets\/img\/","is_premium":"","layout_breakpoint":"992","mobile_overlay_breakpoint":"992","mobile_overlay_wrapper":"body","mobile_overlay_delay":"0","debounce_wait_ms":"400","send_ga_events":"1","enable_ga_site_search_module":"","magnifier_icon":"<img class=\"\"src=\"https:\/\/tabakkatabacaria.com\/wp-content\/uploads\/2022\/05\/search.png\" alt=\"Search icon\" width=\"70\" height=\"70\" \/>","magnifier_icon_pirx":"<img class=\"\"src=\"https:\/\/tabakkatabacaria.com\/wp-content\/uploads\/2022\/05\/search.png\" alt=\"Search icon\" width=\"70\" height=\"70\" \/>","history_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"18\" height=\"16\">\n\t\t\t\t\t<g transform=\"translate(-17.498822,-36.972165)\">\n\t\t\t\t\t\t<path \t\t\t\t\t\t\td=\"m 26.596964,52.884295 c -0.954693,-0.11124 -2.056421,-0.464654 -2.888623,-0.926617 -0.816472,-0.45323 -1.309173,-0.860824 -1.384955,-1.145723 -0.106631,-0.400877 0.05237,-0.801458 0.401139,-1.010595 0.167198,-0.10026 0.232609,-0.118358 0.427772,-0.118358 0.283376,0 0.386032,0.04186 0.756111,0.308336 1.435559,1.033665 3.156285,1.398904 4.891415,1.038245 2.120335,-0.440728 3.927688,-2.053646 4.610313,-4.114337 0.244166,-0.737081 0.291537,-1.051873 0.293192,-1.948355 0.0013,-0.695797 -0.0093,-0.85228 -0.0806,-1.189552 -0.401426,-1.899416 -1.657702,-3.528366 -3.392535,-4.398932 -2.139097,-1.073431 -4.69701,-0.79194 -6.613131,0.727757 -0.337839,0.267945 -0.920833,0.890857 -1.191956,1.27357 -0.66875,0.944 -1.120577,2.298213 -1.120577,3.35859 v 0.210358 h 0.850434 c 0.82511,0 0.854119,0.0025 0.974178,0.08313 0.163025,0.109516 0.246992,0.333888 0.182877,0.488676 -0.02455,0.05927 -0.62148,0.693577 -1.32651,1.40957 -1.365272,1.3865 -1.427414,1.436994 -1.679504,1.364696 -0.151455,-0.04344 -2.737016,-2.624291 -2.790043,-2.784964 -0.05425,-0.16438 0.02425,-0.373373 0.179483,-0.477834 0.120095,-0.08082 0.148717,-0.08327 0.970779,-0.08327 h 0.847035 l 0.02338,-0.355074 c 0.07924,-1.203664 0.325558,-2.153721 0.819083,-3.159247 1.083047,-2.206642 3.117598,-3.79655 5.501043,-4.298811 0.795412,-0.167616 1.880855,-0.211313 2.672211,-0.107576 3.334659,0.437136 6.147035,3.06081 6.811793,6.354741 0.601713,2.981541 -0.541694,6.025743 -2.967431,7.900475 -1.127277,0.871217 -2.441309,1.407501 -3.893104,1.588856 -0.447309,0.05588 -1.452718,0.06242 -1.883268,0.01225 z m 3.375015,-5.084703 c -0.08608,-0.03206 -2.882291,-1.690237 -3.007703,-1.783586 -0.06187,-0.04605 -0.160194,-0.169835 -0.218507,-0.275078 L 26.639746,45.549577 V 43.70452 41.859464 L 26.749,41.705307 c 0.138408,-0.195294 0.31306,-0.289155 0.538046,-0.289155 0.231638,0 0.438499,0.109551 0.563553,0.298452 l 0.10019,0.151342 0.01053,1.610898 0.01053,1.610898 0.262607,0.154478 c 1.579961,0.929408 2.399444,1.432947 2.462496,1.513106 0.253582,0.322376 0.140877,0.816382 -0.226867,0.994404 -0.148379,0.07183 -0.377546,0.09477 -0.498098,0.04986 z\"\/>\n\t\t\t\t\t<\/g>\n\t\t\t\t<\/svg>\n\t\t\t\t","close_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" viewBox=\"0 0 24 24\"\n\t\t\t\t\t width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","back_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" viewBox=\"0 0 16 16\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M14 6.125H3.351l4.891-4.891L7 0 0 7l7 7 1.234-1.234L3.35 7.875H14z\" fill-rule=\"evenodd\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","preloader_icon":"\t\t\t\t<svg class=\"dgwt-wcas-loader-circular \" viewBox=\"25 25 50 50\">\n\t\t\t\t\t<circle class=\"dgwt-wcas-loader-circular-path\" cx=\"50\" cy=\"50\" r=\"20\" fill=\"none\"\n\t\t\t\t\t\t stroke-miterlimit=\"10\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","voice_search_inactive_icon":"\t\t\t\t<svg class=\"dgwt-wcas-voice-search-mic-inactive\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\"\n\t\t\t\t\t width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M12 13Q11.15 13 10.575 12.425Q10 11.85 10 11V5Q10 4.15 10.575 3.575Q11.15 3 12 3Q12.85 3 13.425 3.575Q14 4.15 14 5V11Q14 11.85 13.425 12.425Q12.85 13 12 13ZM12 8Q12 8 12 8Q12 8 12 8Q12 8 12 8Q12 8 12 8Q12 8 12 8Q12 8 12 8Q12 8 12 8Q12 8 12 8ZM11.5 20.5V16.975Q9.15 16.775 7.575 15.062Q6 13.35 6 11H7Q7 13.075 8.463 14.537Q9.925 16 12 16Q14.075 16 15.538 14.537Q17 13.075 17 11H18Q18 13.35 16.425 15.062Q14.85 16.775 12.5 16.975V20.5ZM12 12Q12.425 12 12.713 11.712Q13 11.425 13 11V5Q13 4.575 12.713 4.287Q12.425 4 12 4Q11.575 4 11.288 4.287Q11 4.575 11 5V11Q11 11.425 11.288 11.712Q11.575 12 12 12Z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","voice_search_active_icon":"\t\t\t\t<svg class=\"dgwt-wcas-voice-search-mic-active\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\"\n\t\t\t\t\t width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M12 13Q11.15 13 10.575 12.425Q10 11.85 10 11V5Q10 4.15 10.575 3.575Q11.15 3 12 3Q12.85 3 13.425 3.575Q14 4.15 14 5V11Q14 11.85 13.425 12.425Q12.85 13 12 13ZM11.5 20.5V16.975Q9.15 16.775 7.575 15.062Q6 13.35 6 11H7Q7 13.075 8.463 14.537Q9.925 16 12 16Q14.075 16 15.538 14.537Q17 13.075 17 11H18Q18 13.35 16.425 15.062Q14.85 16.775 12.5 16.975V20.5Z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","voice_search_disabled_icon":"\t\t\t\t<svg class=\"dgwt-wcas-voice-search-mic-disabled\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M16.725 13.4 15.975 12.625Q16.1 12.325 16.2 11.9Q16.3 11.475 16.3 11H17.3Q17.3 11.75 17.138 12.337Q16.975 12.925 16.725 13.4ZM13.25 9.9 9.3 5.925V5Q9.3 4.15 9.875 3.575Q10.45 3 11.3 3Q12.125 3 12.713 3.575Q13.3 4.15 13.3 5V9.7Q13.3 9.75 13.275 9.8Q13.25 9.85 13.25 9.9ZM10.8 20.5V17.025Q8.45 16.775 6.875 15.062Q5.3 13.35 5.3 11H6.3Q6.3 13.075 7.763 14.537Q9.225 16 11.3 16Q12.375 16 13.312 15.575Q14.25 15.15 14.925 14.4L15.625 15.125Q14.9 15.9 13.913 16.4Q12.925 16.9 11.8 17.025V20.5ZM19.925 20.825 1.95 2.85 2.675 2.15 20.65 20.125Z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","custom_params":{},"convert_html":"1","suggestions_wrapper":"body","show_product_vendor":"","disable_hits":"","disable_submit":"","fixer":{"broken_search_ui":true,"broken_search_ui_ajax":true,"broken_search_ui_hard":false,"broken_search_elementor_popups":true,"broken_search_jet_mobile_menu":true,"broken_search_browsers_back_arrow":true,"force_refresh_checkout":true},"voice_search_enabled":"","voice_search_lang":"pt-BR","show_recently_searched_products":"","show_recently_searched_phrases":""};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/ajax-search-for-woocommerce/assets/js/search.min.js?ver=1.28.1" id="jquery-dgwt-wcas-js"></script>
<script id="wc-cart-fragments-js-extra">
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_e1581b1aad53fc034bbdf9af3bf4b243","fragment_name":"wc_fragments_e1581b1aad53fc034bbdf9af3bf4b243","request_timeout":"5000"};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=9.3.1" id="wc-cart-fragments-js" defer data-wp-strategy="defer"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.20.1" id="elementor-pro-webpack-runtime-js"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.24.0" id="elementor-webpack-runtime-js"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.24.0" id="elementor-frontend-modules-js"></script>
<script id="elementor-pro-frontend-js-before">
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","nonce":"94d3e41f3d","urls":{"assets":"https:\/\/tabakkatabacaria.com\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/tabakkatabacaria.com\/wp-json\/"},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"},"x-twitter":{"title":"X"},"threads":{"title":"Threads"}},"woocommerce":{"menu_cart":{"cart_page_url":"https:\/\/tabakkatabacaria.com\/carrinho\/","checkout_page_url":"https:\/\/tabakkatabacaria.com\/finalizar-compra\/","fragments_nonce":"31f37f2bd1"}},"facebook_sdk":{"lang":"pt_BR","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/tabakkatabacaria.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.20.1" id="elementor-pro-frontend-js"></script>
<script src="https://tabakkatabacaria.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Compartilhar no Facebook","shareOnTwitter":"Compartilhar no Twitter","pinIt":"Fixar","download":"Baixar","downloadImage":"Baixar imagem","fullscreen":"Tela cheia","zoom":"Zoom","share":"Compartilhar","playVideo":"Reproduzir v\u00eddeo","previous":"Anterior","next":"Pr\u00f3ximo","close":"Fechar","a11yCarouselWrapperAriaLabel":"Carrossel | Rolagem horizontal: Setas para esquerda e direita","a11yCarouselPrevSlideMessage":"Slide anterior","a11yCarouselNextSlideMessage":"Pr\u00f3ximo slide","a11yCarouselFirstSlideMessage":"Este \u00e9 o primeiro slide","a11yCarouselLastSlideMessage":"Este \u00e9 o \u00faltimo slide","a11yCarouselPaginationBulletMessage":"Ir para o slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Dispositivos m\u00f3veis no modo retrato","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Dispositivos m\u00f3veis no modo paisagem","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet no modo retrato","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet no modo paisagem","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Notebook","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Tela ampla (widescreen)","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.24.0","is_static":false,"experimentalFeatures":{"additional_custom_breakpoints":true,"container_grid":true,"e_swiper_latest":true,"e_nested_atomic_repeaters":true,"e_onboarding":true,"theme_builder_v2":true,"home_screen":true,"ai-layout":true,"landing-pages":true,"link-in-bio":true,"floating-buttons":true,"notes":true,"form-submissions":true},"urls":{"assets":"https:\/\/tabakkatabacaria.com\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php"},"nonces":{"floatingButtonsClickTracking":"6353e0979d"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","woocommerce_notices_elements":[]},"post":{"id":0,"title":"P\u00e1gina n\u00e3o encontrada - Tabakka","excerpt":""}};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.24.0" id="elementor-frontend-js"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor-pro/assets/js/preloaded-elements-handlers.min.js?ver=3.20.1" id="pro-preloaded-elements-handlers-js"></script>
<script id="jet-blocks-js-extra">
var jetBlocksData = {"recaptchaConfig":""};
var JetHamburgerPanelSettings = {"ajaxurl":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","isMobile":"false","templateApiUrl":"https:\/\/tabakkatabacaria.com\/wp-json\/jet-blocks-api\/v1\/elementor-template","devMode":"false","restNonce":"3170e721da"};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/jet-blocks/assets/js/jet-blocks.min.js?ver=1.3.10" id="jet-blocks-js"></script>
<script id="jet-elements-js-extra">
var jetElements = {"ajaxUrl":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","isMobile":"false","templateApiUrl":"https:\/\/tabakkatabacaria.com\/wp-json\/jet-elements-api\/v1\/elementor-template","devMode":"false","messages":{"invalidMail":"Please specify a valid e-mail"}};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/jet-elements/assets/js/jet-elements.min.js?ver=2.6.15" id="jet-elements-js"></script>
<script id="jet-woo-builder-js-extra">
var jetWooBuilderData = {"ajax_url":"https:\/\/tabakkatabacaria.com\/wp-admin\/admin-ajax.php","products":"{\"attachment\":\"iwl-js\",\"error\":\"\",\"m\":\"\",\"p\":0,\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment_id\":0,\"name\":\"iwl-js\",\"pagename\":\"\",\"page_id\":0,\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"search_columns\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"update_menu_item_cache\":false,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":10,\"nopaging\":false,\"comments_per_page\":\"50\",\"no_found_rows\":false,\"order\":\"DESC\"}","single_ajax_add_to_cart":""};
</script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/jet-woo-builder/assets/js/frontend.min.js?ver=2.1.10" id="jet-woo-builder-js"></script>
<script src="https://tabakkatabacaria.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.20.1" id="e-sticky-js"></script>
</body>
</html>
